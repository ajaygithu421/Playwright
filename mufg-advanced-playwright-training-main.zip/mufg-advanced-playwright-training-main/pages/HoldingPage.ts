import { Page, Locator, expect } from '@playwright/test';

export class HoldingPage {
  readonly page: Page;
  readonly heading: Locator;
  readonly accountBalance: Locator;
  // readonly logoutButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.heading = page.locator('h1');
    this.accountBalance = page.locator('.balance-value');

    // this.logoutButton = page.getByRole('link', { name: /logout/i });
  }

  async expectLoaded() {
    await expect(this.heading).toHaveText(/Welcome/i);
    await expect(this.accountBalance).toHaveText('₹1,25,000.50');
  }

  // async logout() {
  //   await this.logoutButton.click();
  // }
}