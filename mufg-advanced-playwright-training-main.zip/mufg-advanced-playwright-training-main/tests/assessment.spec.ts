import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { HoldingPage } from '../pages/HoldingPage';

test.describe('Login flow', () => {
  test('verify successful login', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const holdingPage = new HoldingPage(page);

    await loginPage.goto();
    await loginPage.login('demo', 'demo1234');

    // await holdingPage.expectLoaded();
    await expect(page).toHaveURL(/dashboard/);
  });

  test('account balance is displayed in holding page', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const holdingPage = new HoldingPage(page);

    await loginPage.goto();
    await loginPage.login('demo','demo1234');
    await holdingPage.expectLoaded();

    // await secureArea.logout();
    // await expect(page).toHaveURL(/login/);
  });
  });